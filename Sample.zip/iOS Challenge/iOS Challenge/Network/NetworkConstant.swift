//
//  NetworkConstant.swift
//  MarvelExample
//
//  Created by Ajay Sagar Parwani on 14/07/2021.
//

import Foundation

class NetworkConstant {
    
    static let BASE_URL = "https://gateway.marvel.com"
    
    static let PRIVATE_KEY = "343a14da5770488369c75d44605373f5b108e3cd"
    
    static let PUBLIC_KEY = "623271c87158572e4fb330bdb89c2716"
    
    static let LIMIT = 20

}
