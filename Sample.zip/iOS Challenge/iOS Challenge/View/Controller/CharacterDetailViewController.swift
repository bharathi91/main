//
//  CharacterDetailViewController.swift
//  MarvelExample
//
//  Created by Ajay Sagar Parwani on 15/07/2021.
//

import UIKit

class CharacterDetailViewController: UIViewController {
    
    weak var character: Character?
    
    lazy var viewModel : CharacterViewModel = {
        
        let viewModel = CharacterViewModel(character: character)
        return viewModel
    }()
    
    @IBOutlet weak var imgCharacterThumbnail: UIImageView!
    @IBOutlet weak var lblCharacterID: UILabel!
    @IBOutlet weak var lblCharacterTitle: UILabel!
    @IBOutlet weak var lblCharacterComics: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        setupView()
    }
    
    //MARK: - Setup UI
    fileprivate func setupView() {
        self.lblCharacterID.text = viewModel.getID()
        self.lblCharacterTitle.text = viewModel.getName()
        self.lblCharacterComics.text = self.viewModel.getComics()
        
        self.viewModel.getCharacterImage { image in
            if let img = image {
                self.imgCharacterThumbnail.image = img
            }
        }
    }

}
