//
//  Error.swift
//  MarvelExample
//
//  Created by Ajay Sagar Parwani on 15/07/2021.
//

import Foundation

enum NetworkError: Error {
    
    case jsonParsingFailed
    case somethingWierd

}
